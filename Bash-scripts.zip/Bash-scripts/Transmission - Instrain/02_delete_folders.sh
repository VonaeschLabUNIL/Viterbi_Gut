#!/bin/bash

#SBATCH --job-name 02_delete_folders
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 10G
#SBATCH --time 01:00:00

# Define the path to your text file
file_with_folders=/scratch/mcreze/InStrain_scratch/error_subfolders.txt

# Define the parent directory containing the subfolders
parent_directory=/scratch/mcreze/InStrain_scratch/mapping_output

# Read each line from the file and delete the corresponding folder
while IFS= read -r folder_name; do
    folder_path=${parent_directory}/${folder_name}
    if [ -d "$folder_path" ]; then
        echo "Deleting folder: $folder_path"
        rm -r "$folder_path"
    else
        echo "Folder not found: $folder_path"
    fi
done < ${file_with_folders}
