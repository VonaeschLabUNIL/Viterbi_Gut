#!/bin/bash

#SBATCH --job-name 02_1_index_building
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 50G
#SBATCH --time 10:00:00

#Load modules
module load gcc/11.4.0
module load bowtie2/2.5.1

## Variables
index_indir=/scratch/mcreze/InStrain_scratch/Tables/Genomes_db

## Build index
mkdir -p ${index_indir}/bt2_index
bowtie2-build --threads 16 ${index_indir}/allGenomes.fasta ${index_indir}/bt2_index/allGenomes_index