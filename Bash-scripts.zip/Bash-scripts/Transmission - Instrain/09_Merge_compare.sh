#!/bin/bash

###################################################################
# Merge all the GenomeWide comparison tables after inStrain compare
# Margaux Creze
# 07.01.2025
###################################################################


# Define the output file
output_file="instrain_genomeWide_compare.tsv"

# Empty the output file if it already exists
> "$output_file"

# Loop through each VG folder and append the corresponding .tsv files
for tsv_file in /Volumes/pvonaesc/default/D2c/Clinical_projects/Viterbi_Gut/Bioinformatic/3_Strain_Transmission/Stool_samples/InStrain/04_InStrain_Compare/*/output/*_genomeWide_compare.tsv; do
    echo "Processing $tsv_file"
    
    # Skip the header line for all files except the first one
    if [[ ! -s "$output_file" ]]; then
        # First file, copy including header
        cat "$tsv_file" >> "$output_file"
    else
        # Skip the first line (header) for subsequent files
        tail -n +2 "$tsv_file" >> "$output_file"
    fi
done

echo "All .tsv files have been appended into $output_file"
