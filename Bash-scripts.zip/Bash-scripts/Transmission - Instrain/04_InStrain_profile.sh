#!/bin/bash

#SBATCH --job-name 04_InStrain_profiling
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 24 
#SBATCH --mem 250G
#SBATCH --time 16:00:00
#SBATCH --array=1-8


#Load modules
module load gcc/11.4.0
module load miniconda3/22.11.1

#Activate the Instrain environment
eval "$(/dcsrsoft/spack/external/micromamba/1.4.9/bin/micromamba-linux-64 shell hook --shell bash --root-prefix /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/mcreze/MAMBA/mamba_root 2> /dev/null)"
micromamba activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/mcreze/INSTRAIN/instrain

#InStrain profile takes as input a fasta file and a bam file (sorted and indexed!) and runs a series of steps to characterize the nucleotide diversity, SNSs and SNVs, linkage, etc..

# Define directories
indir=/scratch/mcreze/InStrain_scratch/mapping_output
refdir=/scratch/mcreze/InStrain_scratch/Tables/Genomes_db
filedir=/scratch/mcreze/InStrain_scratch/Tables
outdir=/scratch/mcreze/InStrain_scratch/instrain_output/instrain_profile
error_file=/scratch/mcreze/InStrain_scratch/error_profiling_1.txt  # Update with the correct path to error_subfolders.txt

#mkdir -p ${outdir}

# Change to input directory
cd ${indir}

# Define the array variables
#sample=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)
sample=$(sed -n ${SLURM_ARRAY_TASK_ID}p ${error_file})

# Remove failed folder
rm -r ${outdir}/${sample}_inStrainOut 

echo “###############################################”
echo $id “Start time: $(date -u) for sample: ” ${sample}
echo “##############################################”

inStrain profile ${indir}/${sample}/${sample}_sorted_allGenomesMapped.bam ${refdir}/allGenomes.fasta \
    -o ${outdir}/${sample}_inStrainOut \
    -s ${filedir}/genomes.stb \
    -g ${refdir}/prodigal/allGenomes.fna \
    -p 24 \
    --database_mode

echo “##############################################”
echo $id “Finishing time: $(date -u) ”
echo “##############################################”
