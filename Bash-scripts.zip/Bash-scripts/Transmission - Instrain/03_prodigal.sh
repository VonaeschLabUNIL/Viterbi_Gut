#!/bin/bash

#SBATCH --job-name 03_prodigal_1
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 20G
#SBATCH --time 10:00:00

# Module
module load gcc/11.4.0
module load miniconda3/22.11.1

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/dRep/drep

# Variables
indir=/scratch/mcreze/InStrain_scratch/Tables/Genomes_db
outdir=/scratch/mcreze/InStrain_scratch/Tables/Genomes_db/prodigal

#mkdir -p ${outdir}
rm ${outdir}/* #Remove all failed ones

prodigal -i  ${indir}/allGenomes.fasta \
    -d ${outdir}/allGenomes.fna \
    -a ${outdir}/allGenomes.faa