#!/bin/bash

#SBATCH --job-name 08_Save_Comparisons
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 10
#SBATCH --mem 20G
#SBATCH --time 01:00:00
#SBATCH --array=1-121


# Define directories
indir_comp=/scratch/mcreze/InStrain_scratch/instrain_output/instrain_compare
outdir=/scratch/mcreze/InStrain_scratch/To_NAS

# Define the array variables
cd ${indir_comp}
sample=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

# Back up InStrain compare
mkdir -p ${outdir}/04_Instrain_Compare/
cp -r ${indir_comp}/* ${outdir}/04_Instrain_Compare/

