#!/bin/bash

###########################################################
# Dereplicate the MAGs into Strain-level Genome Bins using dREP
# Simon Yersin, Margaux Creze
# 21.11.2024
###########################################################

#SBATCH --partition cpu
#SBATCH --job-name 01_drep_mags
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 32
#SBATCH --mem 50G
#SBATCH --time 48:00:00 #for about 30000 MAGs it took 8h30

# Module
module load gcc/11.4.0
module load miniconda3/22.11.1

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/dRep/drep

# Variables
drep_dir=/scratch/mcreze/InStrain_scratch/Dereplication
mags_dir=/scratch/mcreze/InStrain_scratch/MAGs
genome_info=/scratch/mcreze/InStrain_scratch

# Dereplicate at strain level (ANI 98%)
dRep dereplicate ${drep_dir} \
    -g ${mags_dir}/*.fa \
    --genomeInfo ${genome_info}/checkm_drep.csv \
    -p 32 \
    -pa 0.95 -sa 0.98 -nc 0.30 --S_algorithm fastANI
