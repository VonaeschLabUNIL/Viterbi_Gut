#!/bin/bash

#SBATCH --partition cpu
#SBATCH --job-name 00_transfer
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 10G
#SBATCH --time 01:00:00

# Change to the directory containing the MAGs
cd /scratch/mcreze/InStrain_scratch/MAGs

# Read each line from the file and move the corresponding file
while IFS= read -r prefix; do
    # Check if the file exists before moving
    if [ -e "$prefix" ]; then
        cp "$prefix" /scratch/mcreze/MAGs_to_NAS
    else
        echo "File not found: $prefix"
    fi
done < to_transfert_dRep.txt