#!/bin/bash

#SBATCH --job-name 02_2_map_reads_err_5
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 50G
#SBATCH --time 08:00:00
#SBATCH --array=1-124


#Load modules
module load gcc/11.4.0
module load bowtie2/2.5.1
module load samtools/1.17

# Variables
indir=/scratch/mcreze/InStrain_scratch/Reads
outdir=/scratch/mcreze/InStrain_scratch/mapping_output
index=/scratch/mcreze/InStrain_scratch/Tables/Genomes_db/bt2_index
tmp=/scratch/mcreze/InStrain_scratch/Tmp
error_file=/scratch/mcreze/InStrain_scratch/sorted_error_profiling.txt  # Update with the correct path to error_subfolders.txt

# Define the array variables
#sample_name=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)
sample_name=$(sed -n ${SLURM_ARRAY_TASK_ID}p ${error_file})

# Delete the previous folder which failed
rm -r ${outdir}/${sample_name}

# Create new directory for each sample
mkdir -p ${outdir}/${sample_name}

echo “###############################################”
echo ${sample_name} “Start time: $(date -u)”
echo “##############################################”

bowtie2 --very-sensitive-local \
	--threads 16 \
	--al-conc-gz ${outdir}/${sample_name}/${sample_name}_bowtie2_R%_001.fastq.gz \
	-x ${index}/allGenomes_index \
	-1 ${indir}/${sample_name}/${sample_name}_Host_Extracted_R1_001.fastq.gz -2 ${indir}/${sample_name}/${sample_name}_Host_Extracted_R2_001.fastq.gz \
	-S ${outdir}/${sample_name}/${sample_name}_allGenomesMapped.sam \
	2> ${outdir}/${sample_name}/${sample_name}_bowtie2.log

echo “##############################################”
echo ${sample_name} “Bowtie Finishing time and Samtool starting time: $(date -u) ”
echo “##############################################”

# Convert .sam files obtained after alignments to .bam file and sort it 
samtools view -F 4 -bh ${outdir}/${sample_name}/${sample_name}_allGenomesMapped.sam \
    | samtools sort -O bam -@ 4 -m 4G -T ${tmp} \
    -o ${outdir}/${sample_name}/${sample_name}_sorted_allGenomesMapped.bam

# Index the sorted BAM file
samtools index ${outdir}/${sample_name}/${sample_name}_sorted_allGenomesMapped.bam

rm ${outdir}/${sample_name}/${sample_name}_allGenomesMapped.sam

echo “##############################################”
echo ${sample_name} “Finishing time: $(date -u)”
echo “##############################################”
