#!/bin/bash


#SBATCH --job-name 07_Pairs_without_transmission
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 4
#SBATCH --mem 5G
#SBATCH --time 00:05:00

# Define the output file
output_file="/users/mcreze/InStrain/Scripts/VG_ID_without_transmission_notsort.txt"

# Empty the output file if it already exists
> "$output_file"

# Loop over all .err files matching the pattern
cd /scratch/mcreze/InStrain_scratch/std_output
for input_file in 05_InStrain_compare_pairwise_complete*.err; do
    echo "Processing file: $input_file"
    
    # Initialize a variable to keep track of the current sample
    current_sample=""

    # Read the input file line by line
    while IFS= read -r line; do
        # Check if the line contains the sample information
        if [[ $line =~ /scratch/mcreze/InStrain_scratch/instrain_output/instrain_profile/([^_]+)_inStrainOut ]]; then
            current_sample="${BASH_REMATCH[1]}"
            # Transform sample name: replace "C1WST" with "VG"
            current_sample="VG${current_sample#C1WST}"
        fi
        # Check if the line contains the error pattern
        if [[ $line == *"No scaffolds are shared among the IS objects"* ]]; then
            # Write the transformed sample name to the output file
            echo "$current_sample" >> "$output_file"
        fi
    done < "$input_file"
done

cd /users/mcreze/InStrain/Scripts
sort VG_ID_without_transmission_notsort.txt -o VG_ID_without_transmission_sorted.txt
uniq VG_ID_without_transmission_sorted.txt > VG_ID_without_transmission.txt

rm /users/mcreze/InStrain/Scripts/VG_ID_without_transmission_notsort.txt
rm /users/mcreze/InStrain/Scripts/VG_ID_without_transmission_sorted.txt

echo "Output written to VG_ID_without_transmission.txt"
