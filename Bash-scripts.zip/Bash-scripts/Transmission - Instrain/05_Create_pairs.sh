#!/bin/bash

#SBATCH --job-name 05_Create_pairs
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 2
#SBATCH --mem 1G
#SBATCH --time 00:10:00


# Directories
profile_dir=/scratch/mcreze/InStrain_scratch/instrain_output/instrain_profile

# List child and mother sample files
find ${profile_dir} -type d -name 'C1WST*' > child_samples.txt
find ${profile_dir} -type d -name 'MPST*' > mother_samples.txt

# Generate pairs
while IFS= read -r child; do
    # Extract the numeric part of the child sample, allowing for optional r or t suffix
    child_num=$(basename "$child" | sed -E 's/^C1WST([0-9]+)[rt]?_inStrainOut$/\1/')

    # Find the corresponding mother sample with optional r or t suffix
    mother=$(grep -E "MPST${child_num}[rt]?_inStrainOut" mother_samples.txt)

    # Check if the pair exists
    if [ -n "$mother" ]; then
        echo "$mother $child" >> pairs_1.txt
    else
        echo "No matching mother sample for $child" >> unmatched_pairs.txt
    fi
done < child_samples.txt

# Now check for mothers with no matching child sample
while IFS= read -r mother; do
    # Extract the numeric part of the mother sample
    mother_num=$(basename "$mother" | sed -E 's/^MPST([0-9]+)[rt]?_inStrainOut$/\1/')

    # Find the corresponding child sample with optional r or t suffix
    child=$(grep -E "C1WST${mother_num}[rt]?_inStrainOut" child_samples.txt)

    # Check if the pair exists (if no child is found)
    if [ -z "$child" ]; then
        echo "No matching child sample for $mother" >> unmatched_pairs.txt
    fi
done < mother_samples.txt

# Clean up the file paths to match your needs
sed -i 's|/scratch/mcreze/InStrain_scratch/instrain_output/instrain_profile/||g' pairs_1.txt
sed -i 's|/scratch/mcreze/InStrain_scratch/instrain_output/instrain_profile/||g' unmatched_pairs.txt

sort pairs_1.txt -o pairs_sorted.txt
uniq pairs_sorted.txt > pairs.txt

# Clean up temporary files
rm child_samples.txt mother_samples.txt
rm pairs_1.txt pairs_sorted.txt
