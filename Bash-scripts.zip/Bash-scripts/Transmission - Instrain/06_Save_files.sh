#!/bin/bash

#SBATCH --job-name 06_Save_files
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 10
#SBATCH --mem 30G
#SBATCH --time 01:00:00
#SBATCH --array=1-470


# Define directories
indir_map=/scratch/mcreze/InStrain_scratch/mapping_output
indir_pro=/scratch/mcreze/InStrain_scratch/instrain_output/instrain_profile
indir_comp=/scratch/mcreze/InStrain_scratch/instrain_output/instrain_compare
outdir=/scratch/mcreze/InStrain_scratch/To_NAS

mkdir -p ${outdir}

# Define the array variables
cd ${indir_map}
sample=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

# Back up mapping outputs
mkdir -p ${outdir}/02_Mapping_output/${sample}
cp ${indir_map}/${sample}/${sample}*.bam ${outdir}/02_Mapping_output/${sample}
cp ${indir_map}/${sample}/${sample}*.bai ${outdir}/02_Mapping_output/${sample}

# Back up InStrain profiles
mkdir -p ${outdir}/03_Instrain_Profiles/${sample}
cp -r ${indir_pro}/${sample}_inStrainOut/log ${outdir}/03_Instrain_Profiles/${sample}
cp -r ${indir_pro}/${sample}_inStrainOut/output ${outdir}/03_Instrain_Profiles/${sample}
cp -r ${indir_pro}/${sample}_inStrainOut/raw_data ${outdir}/03_Instrain_Profiles/${sample}


