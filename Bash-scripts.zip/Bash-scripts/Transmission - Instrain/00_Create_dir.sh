#!/bin/bash

#SBATCH --partition cpu
#SBATCH --job-name 00_create_dir
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 10G
#SBATCH --time 01:00:00

cd /scratch/mcreze/InStrain_scratch/Reads

for prefix in $(ls *.fastq.gz | sed -E 's/_Host_Extracted_R[12]_001[.]fastq.gz$//' | uniq)
	do
    mkdir ${prefix}
    cp ${prefix}_Host_Extracted_R1_001.fastq.gz ${prefix}
    cp ${prefix}_Host_Extracted_R2_001.fastq.gz ${prefix}
done     
