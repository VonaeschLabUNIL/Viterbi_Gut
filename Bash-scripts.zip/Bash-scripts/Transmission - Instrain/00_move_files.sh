#!/bin/bash

#SBATCH --partition cpu
#SBATCH --job-name 00_move_files
#SBATCH --output /scratch/mcreze/InStrain_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/InStrain_scratch/std_output/%x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 10G
#SBATCH --time 01:00:00

# Change to the directory containing the MAGs
cd /scratch/mcreze/InStrain_scratch/MAGs

# Create the destination directory if it doesn't exist
mkdir -p /scratch/mcreze/InStrain_scratch/Low_Q_MAGs

# Read each line from the file and move the corresponding file
while IFS= read -r prefix; do
    # Check if the file exists before moving
    if [ -e "$prefix" ]; then
        mv "$prefix" /scratch/mcreze/InStrain_scratch/Low_Q_MAGs/
    else
        echo "File not found: $prefix"
    fi
done < 01_low_quality_MAGs.txt
