#!/bin/bash

###############################################
# MetaSPAdes to assemble the reads into contigs
# Simon Yersin, Margaux Creze
# 01.10.2024
###############################################

#SBATCH --partition cpu
#SBATCH --job-name 01_metaSPAdes
#SBATCH --output /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 32
#SBATCH --mem 400G
#SBATCH --time 20:00:00 #make sure to go up for mothers (around 40-48h)
#SBATCH --array=1-227

## Load modules
module load gcc/11.4.0
module load spades/3.15.5
module load python/3.10.13

## Variables
spades_workdir=/scratch/mcreze/MAGs_child_scratch
spades_indir=/scratch/mcreze/MAGs_child_scratch/Data
spades_outdir=/scratch/mcreze/MAGs_child_scratch/Output_data/metaspades
keep_dir=/users/mcreze/MAGs_child/Output/01_MetaSPAdes

## Array variables
cd ${spades_outdir} #it was spades_indir
sample_name=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)
cd ${spades_workdir}

## Create directory
mkdir -p ${spades_outdir}/${sample_name}
mkdir -p ${keep_dir}/${sample_name}

echo “##############################################”
echo ${sample_name} “Start time: $(date -u)”
echo “##############################################”

## Run metaSPAdes
spades.py --meta \
    --pe1-1 ${spades_indir}/${sample_name}/${sample_name}_Host_Extracted_R1_001.fastq.gz \
    --pe1-2 ${spades_indir}/${sample_name}/${sample_name}_Host_Extracted_R2_001.fastq.gz \
    -o ${spades_outdir}/${sample_name} \
    -k 21,33,55,77,99,127

# Cleaning files
rm -r ${spades_outdir}/${sample_name}/misc
rm -r ${spades_outdir}/${sample_name}/K*
rm -r ${spades_outdir}/${sample_name}/tmp

# Copy important files to /users directory
cp ${spades_outdir}/${sample_name}/assembly_graph.fastg ${keep_dir}/${sample_name}
cp ${spades_outdir}/${sample_name}/contigs.fasta ${keep_dir}/${sample_name}
cp ${spades_outdir}/${sample_name}/scaffolds.fasta ${keep_dir}/${sample_name}
cp ${spades_outdir}/${sample_name}/spades.log ${keep_dir}/${sample_name}

gzip ${keep_dir}/${sample_name}/*.fasta
gzip ${keep_dir}/${sample_name}/*.fastg

echo “##############################################”
echo ${sample_name} “Finishing time: $(date -u) ”
echo “##############################################”