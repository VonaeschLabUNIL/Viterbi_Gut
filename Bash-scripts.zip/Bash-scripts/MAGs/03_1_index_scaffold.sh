#!/bin/bash

###############################################
# Index building on min 1000bp scaffolds for bowtie2
# Margaux Creze (Simon's script)
# 03.10.2024
###############################################

#SBATCH --partition cpu
#SBATCH --job-name 03_01_build_index
#SBATCH --output /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 20G
#SBATCH --time 01:00:00
#SBATCH --array=10,129,143,185

## Load module
module load gcc/11.4.0
module load bowtie2/2.5.1

## Variables
index_indir=/scratch/mcreze/MAGs_child_scratch/Output_data/metaspades

## Array variables
cd ${index_indir}
sample_name=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

## Build index
mkdir -p ${index_indir}/${sample_name}/${sample_name}_index
bowtie2-build ${index_indir}/${sample_name}/${sample_name}.scaffolds.min1000.fasta ${index_indir}/${sample_name}/${sample_name}_index/${sample_name}

## Copy the indexes in /users
#mkdir -p /users/syersin2/mags_analysis/${sample_name}/${sample_name}_index
#cp ${index_indir}/${sample_name}/${sample_name}_index/*.bt2 /users/syersin2/mags_analysis/${sample_name}/${sample_name}_index/