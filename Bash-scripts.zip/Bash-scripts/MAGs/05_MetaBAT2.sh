#!/bin/bash

###############################################
# Cluster metagenomic contigs into different bins using MetaBAT2
# Simon Yersin, Margaux Creze
# 21.10.2024
###############################################

#SBATCH --partition cpu
#SBATCH --job-name 05_MetaBAT2_binning
#SBATCH --output /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 2G
#SBATCH --time 04:00:00
#SBATCH --array=3-227

## Load module
module load gcc/11.4.0
module load miniconda3/22.11.1

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaBAT2/metabat2

## Variables
bin_indir=/scratch/mcreze/MAGs_child_scratch/Output_data/metaspades
bin_outdir=/scratch/mcreze/MAGs_child_scratch/MAGs_output
keep_dir=/users/mcreze/MAGs_child/Output/04_MAGs

## Array variables
cd ${bin_indir}
sample_name=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

## Create directories
mkdir -p ${bin_outdir}/MAGs/${sample_name} #before it was mkdir -p ${bin_outdir}/MAGs
mkdir -p ${keep_dir}

## Metagnomic binnnig
echo "#####################################################"
echo $id " Start time : $(date -u)"
echo "#####################################################"

metabat2 -i ${bin_indir}/${sample_name}/${sample_name}.scaffolds.min1000.fasta \
    -a ${bin_indir}/${sample_name}/${sample_name}_depth/${sample_name}.depth \
    -o ${bin_outdir}/MAGs/${sample_name}/ \
    --minContig 2000 \
    --maxEdges 500 \
    --minCV 1 \
    --minClsSize 200000 \
    --saveCls -v

# Copy MAGs bins to /users:
#cp ${bin_outdir}/MAGs/${sample_name} /users/syersin2/mags_test/mags_analysis/MAGs
cp ${bin_outdir}/MAGs/*.fa ${keep_dir}/${sample_name}
gzip ${keep_dir}/*.fa

echo "#####################################################"
echo $id " Finishing time : $(date -u)"
echo "#####################################################"