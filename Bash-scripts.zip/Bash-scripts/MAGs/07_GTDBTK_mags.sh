#!/bin/bash

###############################################
# MAGs taxonomy assignation
# Simon Yersin, Margaux Creze
# 31.10.2024
###############################################

#SBATCH --job-name 07_GTDBTK
#SBATCH --output /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 150G
#SBATCH --time 10:00:00

# Module
module load gcc/11.4.0
module load miniconda3/22.11.1

# Activate conda environment - DO NOT MODIFY!
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/GTDB_TK/gtdbtk

#### Create directories and define variables
gtdb_indir=/scratch/mcreze/MAGs_child_scratch/MAGs_output
gtdb_keep=/users/mcreze/MAGs_child/Output/GTDB

## Create output directory
mkdir -p ${gtdb_indir}/GTDB
mkdir -p ${gtdb_keep}

# Run GTBD-Tk
gtdbtk classify_wf --genome_dir ${gtdb_indir}/MAGs_1 \
    --out_dir ${gtdb_indir}/GTDB \
    --mash_db ${gtdb_indir}/GTDB/gtdbtk.msh \
    --extension fa \
    --cpus 16

# Save output files to /users
cp ${qc_indir}/GTDB/gtdbtk.bac120.summary.tsv ${gtdb_keep}
cp ${qc_indir}/GTDB/gtdbtk.log ${gtdb_keep}
cp ${qc_indir}/GTDB/gtdbtk.warnings.log ${gtdb_keep}