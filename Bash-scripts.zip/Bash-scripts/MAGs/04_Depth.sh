#!/bin/bash

###############################################
# Within- and between-sample abundance correlation
# Simon Yersin, Margaux Creze
# 21.10.2024
###############################################

#SBATCH --partition cpu
#SBATCH --job-name 04_depth
#SBATCH --output /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 10G
#SBATCH --time 04:00:00
#SBATCH --array=1-227

## Load module
module load gcc/11.4.0
module load miniconda3/22.11.1

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaBAT2/metabat2

## Variables
depth_indir=/scratch/mcreze/MAGs_child_scratch/Output_data/metaspades
keep_dir=/users/mcreze/MAGs_child/Output/03_Depth

## Array variables
cd ${depth_indir}
sample_name=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

## Generate depth
mkdir -p ${depth_indir}/${sample_name}/${sample_name}_depth

echo "#####################################################"
echo $id " Start time : $(date -u)"
echo "#####################################################"

jgi_summarize_bam_contig_depths --outputDepth ${depth_indir}/${sample_name}/${sample_name}_depth/${sample_name}.depth \
    ${depth_indir}/${sample_name}/${sample_name}_backmapping/*.bam

# Copying the depth files:
mkdir -p ${keep_dir}
cp -r ${depth_indir}/${sample_name}/${sample_name}_depth ${keep_dir}

echo "#####################################################"
echo $id " Finishing time : $(date -u)"
echo "#####################################################"