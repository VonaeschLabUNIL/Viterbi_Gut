#!/bin/bash

###############################################
# Backmapping the reads on the scaffold using bowtie2
# Simon Yersin, Margaux Creze
# 03.10.2024
###############################################

#SBATCH --partition cpu
#SBATCH --job-name 03_02_backmapping_under_All
#SBATCH --output /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 36
#SBATCH --mem 200G
#SBATCH --time 40:00:00 #increase to 60h if needed
#SBATCH --array=1-38

## Load module
module load gcc/11.4.0
module load bowtie2/2.5.1
module load samtools/1.17

## Variables
index_indir=/scratch/mcreze/MAGs_child_scratch/Output_data/metaspades
reads_indir=/scratch/mcreze/MAGs_child_scratch/Data
tmp=/scratch/mcreze/MAGs_child_scratch/tmp

## Array variables
config=/users/mcreze/MAGs_child/Scripts/config_under_All.txt
cd ${index_indir}
sample_name=$(awk -v ArrayTaskID=$SLURM_ARRAY_TASK_ID '$1==ArrayTaskID {print $2}' $config)

## Backmapping
rm -r ${index_indir}/${sample_name}/${sample_name}_backmapping
mkdir -p ${index_indir}/${sample_name}/${sample_name}_backmapping

echo "#####################################################"
echo $id " Start time of the loop : $(date -u)"
echo "#####################################################"

for reads in $(awk 'NR >= 1 && NR <= 38 {print $2}' $config)
    do
    echo "Alignment of " ${reads} " on " ${sample_name} " is running and starts at $(date -u)" 
    bowtie2 -x ${index_indir}/${sample_name}/${sample_name}_index/${sample_name} \
        -1 ${reads_indir}/${reads}/${reads}_Host_Extracted_R1_001.fastq.gz \
        -2 ${reads_indir}/${reads}/${reads}_Host_Extracted_R2_001.fastq.gz \
        -S ${index_indir}/${sample_name}/${sample_name}_backmapping/${reads}_mapped_to_${sample_name}.sam \
        --threads 36
    echo "Changing alignment of " ${reads} " on " ${sample_name} " to sorted bam file at $(date -u)"
    samtools view -F 4 -bh ${index_indir}/${sample_name}/${sample_name}_backmapping/${reads}_mapped_to_${sample_name}.sam \
        | samtools sort -O bam -@ 4 -m 4G -T ${tmp} > ${index_indir}/${sample_name}/${sample_name}_backmapping/${reads}_mapped_to_${sample_name}.bam
    rm ${index_indir}/${sample_name}/${sample_name}_backmapping/${reads}_mapped_to_${sample_name}.sam
    echo "Alignment of " ${reads} " on " ${sample_name} " is completed at $(date -u)"
done

echo "#####################################################"
echo $id " Finishing time of the loop : $(date -u)"
echo "#####################################################"