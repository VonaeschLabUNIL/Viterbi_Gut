#!/bin/bash

###########################################################
# Filtering scaffolds to minimum 500bp and 1000bp in length
# Margaux Creze (Simon's script)
# 03.10.2024
###########################################################

#SBATCH --partition cpu
#SBATCH --job-name 02_contigs_filtering
#SBATCH --output /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 2G
#SBATCH --time 01:00:00
#SBATCH --array=1-227

## Load modules
module load gcc/11.4.0
module load python/3.10.13 
module load miniconda3/22.11.1

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/BioPython/biopython

## Variables
filter_workdir=/scratch/mcreze/MAGs_child_scratch
filter_indir=/scratch/mcreze/MAGs_child_scratch/Output_data/metaspades
keep_dir=/users/mcreze/MAGs_child/Output/02_Scaffolds

## Array variables
cd ${filter_indir}
sample_name=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)
cd ${filter_workdir}

echo “##############################################”
echo “${sample_name} Start time: $(date -u)”
echo “##############################################”

## Run contigs filtering
python /users/mcreze/MAGs_child/Scripts/scaffold_filter.py ${sample_name} scaffolds ${filter_indir}/${sample_name}/scaffolds.fasta ${filter_indir}/${sample_name}/ META
python /users/mcreze/MAGs_child/Scripts/scaffold_filter.py ${sample_name} contigs ${filter_indir}/${sample_name}/contigs.fasta ${filter_indir}/${sample_name}/ META

## Get assembly stats
assembly-stats -l 500 -t <(cat ${filter_indir}/${sample_name}/${sample_name}.scaffolds.min500.fasta) > ${filter_indir}/${sample_name}/${sample_name}.min500.assembly.stats
assembly-stats -l 1000 -t <(cat ${filter_indir}/${sample_name}/${sample_name}.scaffolds.min1000.fasta) > ${filter_indir}/${sample_name}/${sample_name}.min1000.assembly.stats

echo “##############################################”
echo ${sample_name} “Finishing time: $(date -u) ”
echo “##############################################”

mkdir -p ${keep_dir}/${sample_name}

## Copy important files to /users directory
cp ${filter_indir}/${sample_name}/${sample_name}.min500.assembly.stats ${keep_dir}/${sample_name}
cp ${filter_indir}/${sample_name}/${sample_name}.min1000.assembly.stats ${keep_dir}/${sample_name}
cp ${filter_indir}/${sample_name}/${sample_name}.scaffolds.min500.fasta ${keep_dir}/${sample_name}
cp ${filter_indir}/${sample_name}/${sample_name}.scaffolds.min1000.fasta ${keep_dir}/${sample_name}

gzip ${keep_dir}/${sample_name}/*.fasta