#!/bin/bash

###############################################
# MAGs Quality Control using CheckM
# Simon Yersin, Margaux Creze
# 22.10.2024
###############################################

#SBATCH --partition cpu
#SBATCH --job-name 06_CheckM_MAGs
#SBATCH --output /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MAGs_child_scratch/std_output/%x_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 10G
#SBATCH --time 01:00:00
#SBATCH --array=1-225

# Module
module load gcc/11.4.0
module load miniconda3/22.11.1

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/checkM/checkm

# Variables
qc_indir=/scratch/mcreze/MAGs_child_scratch/MAGs_output

## Array variables
cd ${qc_indir}/MAGs
sample_name=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)


echo “###############################################”
echo ${sample_name} “Start time: $(date -u)”
echo “##############################################”

# Run checkm
mkdir -p ${qc_indir}/checkM/${sample_name}

checkm lineage_wf ${qc_indir}/MAGs/${sample_name}/ \
    ${qc_indir}/checkM/${sample_name}/ \
    -x fa \
    -t 36 \
    -f ${qc_indir}/checkM/${sample_name}/${sample_name}_checkM_stats.tsv \
    --tab_table

echo “##############################################”
echo ${sample_name} “Finishing time: $(date -u) ”
echo “##############################################”

# Saving files 
cd ${qc_indir}/checkM/${sample_name}
rename -v checkm "${sample_name}_checkm" checkm.log
mkdir -p /users/mcreze/MAGs_child/Output/checkM
mkdir -p /users/mcreze/MAGs_child/Output/checkM/Logs
cp ${qc_indir}/checkM/${sample_name}/${sample_name}_checkM_stats.tsv /users/mcreze/MAGs_child/Output/checkM
cp ${qc_indir}/checkM/${sample_name}/${sample_name}_checkm.log /users/mcreze/MAGs_child/Output/checkM/Logs


