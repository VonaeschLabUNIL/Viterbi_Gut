import csv

input_file = "/scratch/mcreze/Stool_samples_scratch/ABRicate_resistome/Abricate_out/combined_abricate.tsv"
output_file = "/scratch/mcreze/Stool_samples_scratch/ABRicate_resistome/Abricate_out/combined_clean.tsv"

# Read master header
with open("master_header.txt") as f:
    master_header = f.readline().strip().split("\t")

# Prepare output writer
with open(output_file, "w", newline='') as out_f:
    writer = csv.DictWriter(out_f, fieldnames=master_header, delimiter="\t")
    writer.writeheader()

    with open(input_file) as in_f:
        for line in in_f:
            if line.startswith("#FILE"):
                continue  # skip header lines

            parts = line.strip().split("\t")
            if not parts or len(parts) < 2:
                continue

            row = dict()
            for i in range(min(len(master_header), len(parts))):
                row[master_header[i]] = parts[i]

            writer.writerow(row)
