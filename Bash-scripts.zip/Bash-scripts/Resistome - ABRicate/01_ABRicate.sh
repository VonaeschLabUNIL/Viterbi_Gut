#!/bin/bash

#SBATCH --partition cpu
#SBATCH --job-name 01_abricate
#SBATCH --output /scratch/mcreze/Stool_samples_scratch/ABRicate_resistome/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/Stool_samples_scratch/ABRicate_resistome/std_output/%x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 1
#SBATCH --mem 150M
#SBATCH --time 00:30:00
#SBATCH --array 1-577

# -------------------------------
# Settings
# -------------------------------
SAMPLES_PER_JOB=10

datadir=/scratch/mcreze/Stool_samples_scratch/ABRicate_resistome/MAGs
outdir=/scratch/mcreze/Stool_samples_scratch/ABRicate_resistome/Abricate_out

# -------------------------------
# Environment
# -------------------------------
module load gcc/12.3.0
module load miniforge3/4.8.3-4-Linux-x86_64

eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/ABRicate/abricate

# -------------------------------
# Determine which samples this array task will process
# -------------------------------
start=$(( (SLURM_ARRAY_TASK_ID - 1) * SAMPLES_PER_JOB + 1 ))
end=$(( SLURM_ARRAY_TASK_ID * SAMPLES_PER_JOB ))

# -------------------------------
# Loop over samples in this chunk
# -------------------------------
for i in $(seq $start $end); do
    sample_file=$(find "${datadir}" -maxdepth 1 -type f -name "*.fa" | sort | sed -n ${i}p)
    [ -z "$sample_file" ] && continue   # skip if no file left

    sample_name=$(basename "$sample_file" .fa)

    echo "Processing sample $sample_name (task $SLURM_ARRAY_TASK_ID)"

    rm -rf "${outdir}/${sample_name}"
    mkdir -p "${outdir}/${sample_name}"

    abricate "${sample_file}" --db card      > "${outdir}/${sample_name}/${sample_name}.card.tab"
    abricate "${sample_file}" --db resfinder > "${outdir}/${sample_name}/${sample_name}.resfinder.tab"
    abricate "${sample_file}" --db argannot  > "${outdir}/${sample_name}/${sample_name}.argannot.tab"

    abricate --summary \
        "${outdir}/${sample_name}/${sample_name}.card.tab" \
        "${outdir}/${sample_name}/${sample_name}.resfinder.tab" \
        "${outdir}/${sample_name}/${sample_name}.argannot.tab" \
        > "${outdir}/${sample_name}/${sample_name}.abricate.tsv"
done


# DATABASE        SEQUENCES       DBTYPE  DATE
# megares 6635    nucl    2025-Jan-14
# resfinder       3077    nucl    2025-Jan-14
# card    2631    nucl    2025-Jan-14
# argannot        2223    nucl    2025-Jan-14
# ecoh    597     nucl    2025-Jan-14
# vfdb    2597    nucl    2025-Jan-14
# plasmidfinder   460     nucl    2025-Jan-14
# ecoli_vf        2701    nucl    2025-Jan-14
# ncbi    5386    nucl    2025-Jan-14

# ABRicate can combine results into a simple matrix of gene presence/absence. 
# An absent gene is denoted . and a present gene is represented by its '%COVERAGE`.