#!/bin/bash

#SBATCH --job-name=00_Create_pairs
#SBATCH --output=/scratch/mcreze/StrainPhlan_scratch/std_output/%x_%j.out
#SBATCH --error=/scratch/mcreze/StrainPhlan_scratch/std_output/%x_%j.err
#SBATCH --mail-type=BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user=margaux.creze@unil.ch
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=1G
#SBATCH --time=00:10:00

# Directories
indir="/scratch/mcreze/StrainPhlan_scratch/Consensus_markers"

# List child and mother sample files
find "${indir}" -type f -name 'C1WST*.json.bz2' > child_samples.txt
find "${indir}" -type f -name 'MPST*.json.bz2' > mother_samples.txt

# Generate pairs and track unmatched samples
> unmatched_pairs.log

# Process child samples
while IFS= read -r child; do
    child_num=$(basename "$child" | sed -E 's/^C1WST([0-9]+)[rt]?\.json\.bz2$/\1/')
    mother=$(grep -E "MPST${child_num}[rt]?\.json\.bz2" mother_samples.txt)

    if [ -n "$mother" ]; then
        echo "$mother $child" >> pairs_1.txt
    else
        echo "No matching mother sample for $child" >> unmatched_pairs.log
    fi
done < child_samples.txt

# Process mother samples for unmatched entries
while IFS= read -r mother; do
    mother_num=$(basename "$mother" | sed -E 's/^MPST([0-9]+)[rt]?\.json\.bz2$/\1/')
    child=$(grep -E "C1WST${mother_num}[rt]?\.json\.bz2" child_samples.txt)

    if [ -z "$child" ]; then
        echo "No matching child sample for $mother" >> unmatched_pairs.log
    fi
done < mother_samples.txt

# Clean up file paths and extensions
sed -i 's|/scratch/mcreze/StrainPhlan_scratch/Consensus_markers/||g' pairs_1.txt unmatched_pairs.log

sort pairs_1.txt -o pairs_sorted.txt
uniq pairs_sorted.txt > pairs.txt

sort unmatched_pairs.log -o unmatched_pairs.log

sed -i 's|\.json\.bz2||g' unmatched_pairs.log pairs.txt

# Clean up temporary files
rm child_samples.txt mother_samples.txt pairs_1.txt pairs_sorted.txt
