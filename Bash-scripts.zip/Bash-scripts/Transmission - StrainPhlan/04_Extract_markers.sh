#!/bin/bash

##############################################
# Extract the markers from MetaPhlAn database
# Margaux Creze
# 18.12.2024
##############################################

#SBATCH --partition cpu
#SBATCH --job-name 04_Extract_markers
#SBATCH --output /scratch/mcreze/StrainPhlan_scratch/std_output/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/StrainPhlan_scratch/std_output/%x_%A_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 10
#SBATCH --mem 20G
#SBATCH --time 00:15:00
#SBATCH --array 1-704 #check this line to know how many clades in clade.txt : Thu Jan  9 14:11:26 2025: Detected 704 clades: 

# Module
module load gcc/12.3.0
module load miniforge3/4.8.3

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaPhlan/metaphlan

## Variables
indir=/scratch/mcreze/StrainPhlan_scratch/Consensus_markers
outdir_clade=/scratch/mcreze/StrainPhlan_scratch/CladeMarkers

mkdir -p ${outdir_clade}

# Define array variable
sample=$(grep 't__' clades.txt | sed -E 's/^.*(t__[^:]+):.*$/\1/' | sed -n "${SLURM_ARRAY_TASK_ID}p")

echo “################################”
echo “${sample} Start time: $(date -u)”
echo “################################”

## Extract the markers from MetaPhlAn database
extract_markers.py -c ${sample} \
    -o ${outdir_clade}/

echo “#################################”
echo “${sample} Finish time: $(date -u)”
echo “#################################”