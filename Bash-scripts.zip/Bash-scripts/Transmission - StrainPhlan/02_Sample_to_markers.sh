#!/bin/bash

##################################################################
# Generate a marker file for each sample
# Margaux Creze
# 18.12.2024
##################################################################

#SBATCH --partition cpu
#SBATCH --job-name 02_Sample_to_markers
#SBATCH --output /scratch/mcreze/StrainPhlan_scratch/std_output/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/StrainPhlan_scratch/std_output/%x_%A_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 4
#SBATCH --mem 10G
#SBATCH --time 00:30:00
#SBATCH --array 1-470

# Module
module load gcc/12.3.0
module load miniforge3/4.8.3
module load samtools/1.19.2

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaPhlan/metaphlan

## Variables
array=/scratch/mcreze/StrainPhlan_scratch/Host_extracted_reads
indir=/scratch/mcreze/StrainPhlan_scratch/MetaPhlan_output/sams
outdir=/scratch/mcreze/StrainPhlan_scratch/Consensus_markers

#rm -r ${outdir}
mkdir -p ${outdir}

## Array variables
cd ${array}
sample=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

echo “##################################”
echo “${sample} Start time: $(date -u)”
echo “##################################”

# Generate the marker files
sample2markers.py -i ${indir}/${sample}.sam.bz2 \
    --nproc 10 \
    -o ${outdir}

echo “##################################”
echo “${sample} Finish time: $(date -u)”
echo “##################################”