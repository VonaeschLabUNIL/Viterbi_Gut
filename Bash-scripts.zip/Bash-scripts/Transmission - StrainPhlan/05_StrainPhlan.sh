#!/bin/bash

#####################################
# Generate alignments and then trees
# Margaux Creze
# 18.12.2024
######################################

#SBATCH --partition cpu
#SBATCH --job-name 05_StrainPhlan
#SBATCH --output /scratch/mcreze/StrainPhlan_scratch/std_output/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/StrainPhlan_scratch/std_output/%x_%A_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 10
#SBATCH --mem 20G
#SBATCH --time 00:30:00
#SBATCH --array 1-704 #check this line to know how many clades in clade.txt : Thu Jan  9 14:11:26 2025: Detected 704 clades: 

# Module
module load gcc/12.3.0
module load miniforge3/4.8.3
module load samtools/1.19.2
module load blast-plus/2.14.1
module load mafft/7.505
module load raxml/8.2.12

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaPhlan/metaphlan

## Variables
indir=/scratch/mcreze/StrainPhlan_scratch/Consensus_markers
outdir_clade=/scratch/mcreze/StrainPhlan_scratch/CladeMarkers
outdir_sp=/scratch/mcreze/StrainPhlan_scratch/StrainPhlan_output

mkdir -p ${outdir_sp}

# Define array variable
sample=$(grep 't__' clades.txt | sed -E 's/^.*(t__[^:]+):.*$/\1/' | sed -n "${SLURM_ARRAY_TASK_ID}p")

echo “################################”
echo “${sample} Start time: $(date -u)”
echo “################################”

## Build the multiple sequence alignment and the phylogenetic tree
strainphlan -s ${indir}/*.json.bz2 \
    -m ${outdir_clade}/${sample}.fna \
    -o ${outdir_sp} \
    -c ${sample} \
    --marker_in_n_samples 1 \
    --sample_with_n_markers 10 \
    --phylophlan_mode accurate \
    --nproc 10

echo “#################################”
echo “${sample} Finish time: $(date -u)”
echo “#################################”

#More infos here: https://github.com/biobakery/MetaPhlAn/wiki/Strain-Sharing-Inference