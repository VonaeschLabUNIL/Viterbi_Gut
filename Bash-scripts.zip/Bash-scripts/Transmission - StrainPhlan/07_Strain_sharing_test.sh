#!/bin/bash

##############################################
# Strain sharing events are defined as pairs of samples with phylogenetic distance below the strain identity threshold for a certain SGB
# Margaux Creze
# 18.12.2024
##############################################

#SBATCH --partition cpu
#SBATCH --job-name 07_Strain_sharing_test
#SBATCH --output /scratch/mcreze/StrainPhlan_scratch/std_output/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/StrainPhlan_scratch/std_output/%x_%A_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 4
#SBATCH --mem 20G
#SBATCH --time 00:10:00

# Module
module load gcc/12.3.0
module load python/3.8.18
module load miniforge3/4.8.3

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaPhlan/metaphlan

## Variables
indir=/scratch/mcreze/StrainPhlan_scratch/StrainPhlan_output
outdir=/scratch/mcreze/StrainPhlan_scratch/Strain_sharing
mddir=/users/mcreze/StrainPhlan/Scripts
env=/work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaPhlan/metaphlan/bin

mkdir -p ${outdir}/t__SGB17248
#t__8007_group = salivarius
#t__SGB17248 = bifido longum

## Strain sharing
python ${env}/strain_transmission.py \
        --tree ${indir}/RAxML_bestTree.t__SGB17248.StrainPhlAn4.tre \
        --metadata ${mddir}/VG_metadata.tsv \
        --output_dir ${outdir}/t__SGB17248 \
        --sgb_id t__SGB17248