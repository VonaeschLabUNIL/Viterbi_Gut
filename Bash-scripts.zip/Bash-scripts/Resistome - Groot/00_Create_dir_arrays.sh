#!/bin/bash

#SBATCH --partition cpu
#SBATCH --job-name 00_create_dir_array
#SBATCH --output /scratch/jtamarel/VITERBI_GUT_scratch/Stool_samples/Resistome/std_output/%x_%j.out
#SBATCH --error /scratch/jtamarel/VITERBI_GUT_scratch/Stool_samples/Resistome/std_output/%x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8  # Use 8 parallel tasks
#SBATCH --mem 10G
#SBATCH --time 00:10:00
#SBATCH --array 0-244  # Adjust this to process only the remaining samples. For 245 samples, indicate 0-244

cd /scratch/jtamarel/VITERBI_GUT_scratch/Stool_samples/Resistome/Data

# Get list of unique prefixes
prefixes=($(ls *.fastq.gz | sed -E 's/_Host_Extracted_R[12]_001[.]fastq.gz$//' | sort | uniq))

# Select the sample based on SLURM array ID
prefix=${prefixes[$SLURM_ARRAY_TASK_ID]}

# Check if sample is valid
if [[ -z ${prefix} ]]; then
    echo "Error: No sample found for SLURM_ARRAY_TASK_ID=${SLURM_ARRAY_TASK_ID}"
    exit 1
fi

# Create the directory if not exists
mkdir -p ${prefix}

# Copy files in parallel
echo "Copying ${prefix} files..."
cp ${prefix}_Host_Extracted_R[12]_001.fastq.gz ${prefix}/ &
wait  # Wait for all copy processes to finish

echo "Done processing ${prefix}!"
