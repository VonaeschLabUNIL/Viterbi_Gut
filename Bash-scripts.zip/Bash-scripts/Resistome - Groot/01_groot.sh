#!/bin/bash

###############################################################################################
# profiling antibiotic resistance genes in shotgun metagenomics data
# Jeanne Tamarelle (based on Simon and Margaux's scripts)
# 13.03.2026
###############################################################################################

#SBATCH --partition cpu
#SBATCH --job-name 01_groot
#SBATCH --output /scratch/jtamarel/VITERBI_GUT_scratch/Stool_samples/Resistome/std_output/%x_%j.out
#SBATCH --error /scratch/jtamarel/VITERBI_GUT_scratch/Stool_samples/Resistome/std_output/%x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 3G
#SBATCH --time 01:00:00
#SBATCH --array 5,92,116,119,120,127,128,130,133,134,142,144,146,152,155,156,157,159,160,161,162,165,169,172,175,176,180,182,184,188,189,190,194,195,197,198,199,201,202,205,209,210,211,215,218,220,222,226,229,231,243,244

# Module
module load gcc/12.3.0
module load miniforge3/4.8.3-4-Linux-x86_64

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/GROOT/groot
# Groot directory includes: bbmap and biopython

# Variables
datadir=/scratch/jtamarel/VITERBI_GUT_scratch/Stool_samples/Resistome/Data #the host extracted fastq.gz files in sample folders
filt_reads=/scratch/jtamarel/VITERBI_GUT_scratch/Stool_samples/Resistome/reformat
outdir=/scratch/jtamarel/VITERBI_GUT_scratch/Stool_samples/Resistome/groot_out
index_dir=/work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/GROOT/databases/groot-db.90.index
pydir=/users/jtamarel/VITERBI_GUT/Resistome/Stool_samples/Scripts

## Array variables
cd ${datadir}
sample_name=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

# First we filter reads under 31 bases of lenght using bbmap code: reformat.sh
rm -r ${filt_reads}/${sample_name}
mkdir -p ${filt_reads}/${sample_name}

echo “###############################################”
echo ${sample_name} Performing Reformatting - Start time: $(date -u)
echo “##############################################”

reformat.sh in1=${datadir}/${sample_name}/${sample_name}_Host_Extracted_R1_001.fastq.gz \
    in2=${datadir}/${sample_name}/${sample_name}_Host_Extracted_R2_001.fastq.gz \
    out1=${filt_reads}/${sample_name}/${sample_name}_reformat_R1_001.fastq.gz \
    out2=${filt_reads}/${sample_name}/${sample_name}_reformat_R2_001.fastq.gz \
    minLength=31

echo “##############################################”
echo ${sample_name} Reformatting finishing and Groot alignment starting time: $(date -u)
echo “##############################################”

# Then we align the reads to the indexed database of groot 
rm -r ${outdir}/${sample_name}
mkdir -p ${outdir}/${sample_name}

groot align -p 8 \
    -i ${index_dir} \
    -g ${outdir}/${sample_name} \
    -t 0.95 \
    -f ${filt_reads}/${sample_name}/${sample_name}_reformat_R1_001.fastq.gz,${filt_reads}/${sample_name}/${sample_name}_reformat_R2_001.fastq.gz \
    --log ${outdir}/${sample_name}/${sample_name}.groot.log | groot report -p 8 -c 0.95 --log ${outdir}/${sample_name}/${sample_name}.groot.log > ${outdir}/${sample_name}/${sample_name}.report

echo “##############################################”
echo ${sample_name} Groot alignment finishing time: $(date -u)
echo “##############################################”

# report:  This will report gene, read count, gene length, coverage cigar to STDOUT as tab separated values

python ${pydir}/parse_groot-report.py ${pydir}/res_classes.tsv ${outdir}/${sample_name}/${sample_name}.report

echo “##############################################”
echo ${sample_name} Finished: $(date -u)
echo “##############################################”