#!/bin/bash

#SBATCH --partition cpu
#SBATCH --job-name 00_rename_files
#SBATCH --output /scratch/mcreze/MetaPhlan_scratch/std_output/%x_%j.out
#SBATCH --error /scratch/mcreze/MetaPhlan_scratch/std_output/%x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 10G
#SBATCH --time 01:00:00

cd /scratch/mcreze/MetaPhlan_scratch/Data2

for sample in $(ls *.fastq.gz | sed -E 's/HOST_EXTRACTED_(.*)_FASTP_R[12]_001[.]fastq.gz$/\1/' | uniq)
do
    mv HOST_EXTRACTED_${sample}_FASTP_R1_001.fastq.gz ${sample}_Host_Extracted_R1_001.fastq.gz
    mv HOST_EXTRACTED_${sample}_FASTP_R2_001.fastq.gz ${sample}_Host_Extracted_R2_001.fastq.gz
done
