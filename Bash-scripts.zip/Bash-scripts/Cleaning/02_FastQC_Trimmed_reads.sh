#!/bin/bash

###############################################################################################
# FastQC to generate quality control reports for metagenomic sequencing samples - Trimmed reads
# Margaux Creze (based on Simon's script)
# 21.08.2024
###############################################################################################


#SBATCH --job-name 02_Fastqc_trimmed_reads
#SBATCH --output /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 50G
#SBATCH --time 01:00:00
#SBATCH --array=1-227


#Load modules
module load gcc/11.4.0
module load fastqc/0.12.1

#Create directories
indir=/scratch/mcreze/MetaPhlan_scratch/Trimmed_reads_Child
fastqcdir=/scratch/mcreze/MetaPhlan_scratch/To_NAS/Child/FastQC_Analysis

mkdir -p ${fastqcdir}

# Change to input directory
cd ${indir}

# Define the array variables
sample=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

echo “###############################################”
echo “${sample} Trimmed reads FastQC Start time: $(date -u)”
echo “##############################################”

#Run fastqc on the uncleaned files (still containing host reads)
fastqc ${indir}/${sample}/${sample}_FASTP_R[12]_001.fastq.gz -o ${fastqcdir}  

echo “##############################################”
echo “${sample} Trimmed reads FastQC Finishing time: $(date -u) ”
echo “##############################################”


## Next step is to generate reports of the FastQC files using MultiQC but it is not installed on Urblauna. Thus, once FastQC is done, copy the files on Curnalg and perfom MultiQC
## Multiqc reports:
	# Create a full report from the fastqc files:
		# multiqc ${fastqcdir}/* \
		# --ignore-symlinks \
		# --outdir ${fastqcdir}/MultiQC_files \
		# --filename ALL_REPORTS_MULTIQC \
		# --fullnames \
		# --title ALL_REPORTS_MULTIQC
	# Create a full report of the mapping infos
		# multiqc ${outdir}/* \
		# --ignore-symlinks \
		# --outdir ${fastqcdir}/MultiQC_Mapping_Infos \
		# --filename MULTIQC_MAPPING_INFOS \
		# --fullnames \
		# --title MULTIQC_MAPPING_INFOS


		