#!/bin/bash

#SBATCH --partition cpu
#SBATCH --job-name 06_Merge_metaphlan
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 8G
#SBATCH --time 00:15:00
#SBATCH --output /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.err


# Module
module load gcc/11.4.0
module load miniconda3/22.11.1

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaPhlan/metaphlan

## Variables
mpa_indir=/scratch/mcreze/MetaPhlan_scratch/MetaPhlan_Output_data/MetaPhlan
gtdb_indir=/scratch/mcreze/MetaPhlan_scratch/MetaPhlan_Output_data/GTDB_tax
merge_indir=/scratch/mcreze/MetaPhlan_scratch/MetaPhlan_Output_data/Merged
#mpa_indir=/users/mcreze/Metaphlan/MetaPhlan_Merged_Child_Mother #put all the metaphlan profiles in this new folder (Mother and Child)

mkdir -p ${merge_indir}

merge_metaphlan_tables.py ${mpa_indir}/*_metaphlan_profile.txt > ${merge_indir}/VG_Mother_Preg_metaphlan_relab.txt
merge_metaphlan_tables_abs.py ${mpa_indir}/*_metaphlan_profile.txt > ${merge_indir}/VG_Mother_Preg_metaphlan_abs.txt
#merge_metaphlan_tables.py ${mpa_indir}/*_metaphlan_profile.txt > ${mpa_indir}/VG_Mother_Child_metaphlan_relab.txt

merge_metaphlan_tables.py --gtdb_profiles ${gtdb_indir}/*_gtdb.txt > ${merge_indir}/VG_Mother_Preg_metaphlan_gtdb.txt