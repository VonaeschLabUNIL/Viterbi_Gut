#!/bin/bash

########################################################
# FastP to clean and trim metagenomic sequencing samples
# Margaux Creze (based on Simon's script)
# 06.08.2024
########################################################


#SBATCH --job-name 01_FastP_reads_trimming
#SBATCH --output /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16 #this is the max FastP can deal with
#SBATCH --mem 50G
#SBATCH --time 00:15:00
#SBATCH --array=1-227

#Load modules
module load gcc/11.4.0
module load fastp/0.23.4

#Create directories
indir=/scratch/mcreze/MetaPhlan_scratch/FastP/Raw_reads_Child
outdir=/scratch/mcreze/MetaPhlan_scratch/Trimmed_reads_Child
repdir=/scratch/mcreze/MetaPhlan_scratch/To_NAS/Child/Reports_Trimmed_reads

mkdir -p ${repdir}

# Change to input directory
cd ${indir}

# Define the array variables
sample=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

mkdir -p ${outdir}/${sample}

echo “###############################################”
echo ${sample} “Start time: $(date -u)”
echo “##############################################”

#For paired-end reads:
fastp -i ${sample}/${sample}_R1_001.fastq.gz -I ${sample}/${sample}_R2_001.fastq.gz \
	-o ${outdir}/${sample}/${sample}_FASTP_R1_001.fastq.gz  -O ${outdir}/${sample}/${sample}_FASTP_R2_001.fastq.gz \
	--report_title ${sample}_fastp_report \
	--thread 16 \
	-j ${repdir}/${sample}_fastp.json \
	-h ${repdir}/${sample}_fastp.html

echo “##############################################”
echo ${sample} “Finishing time: $(date -u) ”
echo “##############################################”


# if single-ends :
#echo "performing cleaning on files :" "${prefix}_R1_001.fastq.gz"
#fastp -i "${prefix}_R1_001.fastq.gz" -o TRIMMED_READS/"${prefix}_FASTP_R1_001.fastq.gz" --report_title "${prefix}_fastp_report" --thread 38 -j RREPORTS_TRIMEMD_READS/"${prefix}_fastp".json -h REPORTS_TRIMEMD_READS/"${prefix}_fastp".html

#multiqc ./${repdir}/ --ignore-symlinks --outdir ./${repdir} --filename MULTIQC_ALL_SAMPLE_REPORT --fullnames --title MULTIQC_ALL_SAMPLE_REPORT

#cd ./TRIMMED_READS

