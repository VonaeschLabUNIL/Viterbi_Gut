#!/bin/bash

##################################################################
# Bowtie2 to remove human reads from metagenomic sequencing samples
# Margaux Creze (based on Simon's script)
# 29.08.2024
##################################################################


#SBATCH --partition cpu
#SBATCH --job-name 03_Bowtie2_human_host_reads_cleaning
#SBATCH --output /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 20
#SBATCH --mem 50G
#SBATCH --time 02:00:00
#SBATCH --array=1-227

#Load modules
module load gcc/11.4.0
module load bowtie2/2.5.1


#Create directories
indir=/scratch/mcreze/MetaPhlan_scratch/Trimmed_reads_Child
outdir=/scratch/mcreze/MetaPhlan_scratch/Data
repdir=/scratch/mcreze/MetaPhlan_scratch/To_NAS/Child/Reports_Host_extracted_reads
refgen=/scratch/mcreze/MetaPhlan_scratch/Bowtie2/Bowtie_Reference_genome

mkdir -p ${repdir}

###### Automation of alignment
# Building of genome index on which we want to align: necessary for Bowtie2
# Put the fasta file reference genome that will be used for bowtie index in the reference genome directory ${refgen}
# ASSUMES ZIPPED FILES

# Change to input directory
cd ${indir}

# Define the array variables
sample=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

mkdir -p ${outdir}/${sample}

echo “###############################################”
echo ${sample} “Start time: $(date -u)”
echo “##############################################”

bowtie2 --very-sensitive-local \
	--threads 20 \
	--un-conc-gz ${outdir}/${sample}/${sample}_Host_Extracted_R%_001.fastq.gz \
	-x ${refgen}/GRCh38_latest_genomic.INDEX \
	-1 ${indir}/${sample}/${sample}_FASTP_R1_001.fastq.gz -2 ${indir}/${sample}/${sample}_FASTP_R2_001.fastq.gz \
	-S ${outdir}/${sample}/${sample}_GRCh38_latest_genomic.sam \
	2> ${repdir}/${sample}_GRCh38_latest_genomic_BOWTIE2.log

rm ${outdir}/${sample}/${sample}_GRCh38_latest_genomic.sam  #Remove the SAM alignment file 

echo “##############################################”
echo ${sample} “Bowtie - alignment Finishing time: $(date -u) ”
echo “##############################################”


## Infos ##

# https://bowtie-bio.sourceforge.net/bowtie2/manual.shtml#command-line
		# very-sensitive-local: we use the local mode 
		# --un-conc-gz write paired-end reads that failed to align to file ./"${index}.INDEX/HOST_EXTRACTED_${prefix}_R%_001.fastq.gz". The reads that do not map to the human genome are the reads we want to keep for further analysis. The reads that mapped are host contaminants and we want to remove them
		# -p number of threads
		# -x the basename of the index for the reference genome to point to our index
		# -1 out forward input reads file
		# -2 our reverse input reads file
		# -S File to write SAM alignments (output)
		# 2> redirect standard error in a bowtie2.log



