#!/bin/bash

##################################################################
# MetaPhlan 4.1.1 to profile the composition of microbial communities from metagenomic shotgun sequencing data
# Margaux Creze (based on Simon's script)
# 29.08.2024
##################################################################


#SBATCH --partition cpu
#SBATCH --job-name 05_Metaphlan4.1.1
#SBATCH --output /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.out
#SBATCH --error /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%A_%j.err
#SBATCH --mail-type BEGIN,END,FAIL,TIME_LIMIT_80
#SBATCH --mail-user margaux.creze@unil.ch
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 16
#SBATCH --mem 20G
#SBATCH --time 4:00:00
#SBATCH --array=1-227   #ls /scratch/mcreze/MetaPhlan_scratch/Data/ | wc to know how many samples we have in the data folder. 

# Module
module load gcc/11.4.0
module load miniconda3/22.11.1

# Activate conda environment
eval "$(conda shell.bash hook)"
conda activate /work/FAC/FBM/DMF/pvonaesc/vonasch_lab_general/syersin/MetaPhlan/metaphlan

## Variables
mpa_indir=/scratch/mcreze/MetaPhlan_scratch/Data
mpa_outdir=/scratch/mcreze/MetaPhlan_scratch/MetaPhlan_Output_data

mkdir -p ${mpa_outdir}/MetaPhlan
mkdir -p ${mpa_outdir}/GTDB_tax

## Array variables
cd ${mpa_indir}
sample=$(ls | sed -n ${SLURM_ARRAY_TASK_ID}p)

echo “###############################################”
echo ${sample} Performing metaphlan4.1.1 analysis - Start time: $(date -u)
echo “##############################################”

metaphlan ${mpa_indir}/${sample}/${sample}_Host_Extracted_R1_001.fastq.gz \
    --nproc 16 \
    --no_map \
    -t rel_ab_w_read_stats \
    --input_type fastq \
    -o ${mpa_outdir}/MetaPhlan/${sample}_metaphlan_profile.txt

## Change to GTDB taxonomy
sgb_to_gtdb_profile.py -i ${mpa_outdir}/MetaPhlan/${sample}_metaphlan_profile.txt \
    -o ${mpa_outdir}/GTDB_tax/${sample}_gtdb.txt

echo “##############################################”
echo ${sample} Finishing time: $(date -u)
echo “##############################################”

