#!/bin/bash

#SBATCH --partition cpu
#SBATCH --job-name 00_create_dir
#SBATCH --output /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%j.out
#SBATCH --error /scratch/mcreze/MetaPhlan_scratch/std_output_child/%x_%j.err
#SBATCH --nodes 1
#SBATCH --ntasks 1
#SBATCH --cpus-per-task 8
#SBATCH --mem 10G
#SBATCH --time 01:00:00

cd /scratch/mcreze/MetaPhlan_scratch/FastP/Raw_reads_Child

for prefix in $(ls *.fastq.gz | sed -E 's/_R[12]_001[.]fastq.gz$//' | uniq)
	do
    mkdir ${prefix}
    cp ${prefix}_R1_001.fastq.gz ${prefix}
    cp ${prefix}_R2_001.fastq.gz ${prefix}
done